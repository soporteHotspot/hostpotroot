CREATE DATABASE IF NOT EXISTS `db_hotspot_control`;

USE `db_hotspot_control`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `botones`;

CREATE TABLE `botones` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `server` varchar(100) COLLATE utf8_bin NOT NULL,
  `perfil` varchar(100) COLLATE utf8_bin NOT NULL,
  `tiempo` varchar(100) COLLATE utf8_bin NOT NULL,
  `precio` varchar(100) COLLATE utf8_bin NOT NULL,
  `legend` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` varchar(50) COLLATE utf8_bin NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `botones` VALUES (10,"1 hora","all","6Megas","1h",10,8,"[fe80::66d1:54ff:fe50:6c66%6]",1),
(11,"1 horas","all","6Megas","1h",10,9,"192.168.0.104",1),
(12,"5 horas","all","5Megas-xd","5h",23,8,"192.168.0.104",1);
CREATE DATABASE IF NOT EXISTS `db_hotspot_control`;

USE `db_hotspot_control`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `botones`;

CREATE TABLE `botones` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `server` varchar(100) COLLATE utf8_bin NOT NULL,
  `perfil` varchar(100) COLLATE utf8_bin NOT NULL,
  `tiempo` varchar(100) COLLATE utf8_bin NOT NULL,
  `precio` varchar(100) COLLATE utf8_bin NOT NULL,
  `legend` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` varchar(50) COLLATE utf8_bin NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `botones` VALUES (10,"1 hora","all","6Megas","1h",10,8,"[fe80::66d1:54ff:fe50:6c66%6]",1),
(11,"1 horas","all","6Megas","1h",10,9,"192.168.0.104",1),
(12,"5 horas","all","5Megas-xd","5h",23,8,"192.168.0.104",1);
DROP TABLE IF EXISTS `cards`;

CREATE TABLE `cards` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `server` varchar(50) COLLATE utf8_bin NOT NULL,
  `profile` varchar(50) COLLATE utf8_bin NOT NULL,
  `limituptime` varchar(20) COLLATE utf8_bin NOT NULL,
  `comment` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` text COLLATE utf8_bin NOT NULL,
  `descripcion` text COLLATE utf8_bin NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `cards` VALUES (1,"all","TIEMPO-CORRIDO","15d",50,"192.168.0.106","15-dias-xd",1),
(2,"all","TCORRIDO-4M","1d",20,"192.168.5.0","1-dia-cyber",1),
(3,"all","TCORRIDO-4M","15d",50,"192.168.5.0","15-dias-cyber",1),
(4,"all","default","1h",10,"192.168.5.1","1-horasddd",1),
(5,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfgf",1),
(6,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfgff",1),
(7,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfdg",1),
(8,"all","default","554645m","sdfdsfdsf","192.168.5.1","dfgdfg",1),
(9,"all","40M","30m",5,"[fe80::66d1:54ff:fe50:6c66%6]","30m",1),
(10,"all","6Megas","5h",10,"192.168.0.104","5 horas",1),
(11,"all","40M","30d",100,"192.168.0.104","un-mes-xd",1),
(12,"all","FORMAC","30m",5,"[fe80::66d1:54ff:fe50:6c66%6]","30-minutos-prueba",1);
CREATE DATABASE IF NOT EXISTS `db_hotspot_control`;

USE `db_hotspot_control`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `botones`;

CREATE TABLE `botones` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `server` varchar(100) COLLATE utf8_bin NOT NULL,
  `perfil` varchar(100) COLLATE utf8_bin NOT NULL,
  `tiempo` varchar(100) COLLATE utf8_bin NOT NULL,
  `precio` varchar(100) COLLATE utf8_bin NOT NULL,
  `legend` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` varchar(50) COLLATE utf8_bin NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `botones` VALUES (10,"1 hora","all","6Megas","1h",10,8,"[fe80::66d1:54ff:fe50:6c66%6]",1),
(11,"1 horas","all","6Megas","1h",10,9,"192.168.0.104",1),
(12,"5 horas","all","5Megas-xd","5h",23,8,"192.168.0.104",1);
DROP TABLE IF EXISTS `cards`;

CREATE TABLE `cards` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `server` varchar(50) COLLATE utf8_bin NOT NULL,
  `profile` varchar(50) COLLATE utf8_bin NOT NULL,
  `limituptime` varchar(20) COLLATE utf8_bin NOT NULL,
  `comment` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` text COLLATE utf8_bin NOT NULL,
  `descripcion` text COLLATE utf8_bin NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `cards` VALUES (1,"all","TIEMPO-CORRIDO","15d",50,"192.168.0.106","15-dias-xd",1),
(2,"all","TCORRIDO-4M","1d",20,"192.168.5.0","1-dia-cyber",1),
(3,"all","TCORRIDO-4M","15d",50,"192.168.5.0","15-dias-cyber",1),
(4,"all","default","1h",10,"192.168.5.1","1-horasddd",1),
(5,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfgf",1),
(6,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfgff",1),
(7,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfdg",1),
(8,"all","default","554645m","sdfdsfdsf","192.168.5.1","dfgdfg",1),
(9,"all","40M","30m",5,"[fe80::66d1:54ff:fe50:6c66%6]","30m",1),
(10,"all","6Megas","5h",10,"192.168.0.104","5 horas",1),
(11,"all","40M","30d",100,"192.168.0.104","un-mes-xd",1),
(12,"all","FORMAC","30m",5,"[fe80::66d1:54ff:fe50:6c66%6]","30-minutos-prueba",1);
DROP TABLE IF EXISTS `cortes`;

CREATE TABLE `cortes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hora` varchar(10) COLLATE utf8_bin NOT NULL,
  `fecha` date NOT NULL,
  `cantidad` varchar(200) COLLATE utf8_bin NOT NULL,
  `responsable` varchar(100) COLLATE utf8_bin NOT NULL,
  `vendedor` varchar(200) COLLATE utf8_bin NOT NULL,
  `porcentaje` varchar(50) COLLATE utf8_bin NOT NULL,
  `comision` varchar(100) COLLATE utf8_bin NOT NULL,
  `restante` varchar(100) COLLATE utf8_bin NOT NULL,
  `estado` varchar(50) COLLATE utf8_bin NOT NULL,
  `nota` varchar(300) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

INSERT INTO `cortes` VALUES (1,"043642","2024-04-11",285,"otreblaga@gmail.com","admin",1000,2850,-2565,"pagado","admin/corte-admin11-04-2024 04-36-44.pdf"),
(2,"043649","2024-04-11",270,"otreblaga@gmail.com","otreblaga@gmail.com",10,27,243,"pagado","otreblaga@gmail.com/corte-otreblaga@gmail.com11-04-2024 04-36-50.pdf");
CREATE DATABASE IF NOT EXISTS `db_hotspot_control`;

USE `db_hotspot_control`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `botones`;

CREATE TABLE `botones` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `server` varchar(100) COLLATE utf8_bin NOT NULL,
  `perfil` varchar(100) COLLATE utf8_bin NOT NULL,
  `tiempo` varchar(100) COLLATE utf8_bin NOT NULL,
  `precio` varchar(100) COLLATE utf8_bin NOT NULL,
  `legend` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` varchar(50) COLLATE utf8_bin NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `botones` VALUES (10,"1 hora","all","6Megas","1h",10,8,"[fe80::66d1:54ff:fe50:6c66%6]",1),
(11,"1 horas","all","6Megas","1h",10,9,"192.168.0.104",1),
(12,"5 horas","all","5Megas-xd","5h",23,8,"192.168.0.104",1);
DROP TABLE IF EXISTS `cards`;

CREATE TABLE `cards` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `server` varchar(50) COLLATE utf8_bin NOT NULL,
  `profile` varchar(50) COLLATE utf8_bin NOT NULL,
  `limituptime` varchar(20) COLLATE utf8_bin NOT NULL,
  `comment` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` text COLLATE utf8_bin NOT NULL,
  `descripcion` text COLLATE utf8_bin NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `cards` VALUES (1,"all","TIEMPO-CORRIDO","15d",50,"192.168.0.106","15-dias-xd",1),
(2,"all","TCORRIDO-4M","1d",20,"192.168.5.0","1-dia-cyber",1),
(3,"all","TCORRIDO-4M","15d",50,"192.168.5.0","15-dias-cyber",1),
(4,"all","default","1h",10,"192.168.5.1","1-horasddd",1),
(5,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfgf",1),
(6,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfgff",1),
(7,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfdg",1),
(8,"all","default","554645m","sdfdsfdsf","192.168.5.1","dfgdfg",1),
(9,"all","40M","30m",5,"[fe80::66d1:54ff:fe50:6c66%6]","30m",1),
(10,"all","6Megas","5h",10,"192.168.0.104","5 horas",1),
(11,"all","40M","30d",100,"192.168.0.104","un-mes-xd",1),
(12,"all","FORMAC","30m",5,"[fe80::66d1:54ff:fe50:6c66%6]","30-minutos-prueba",1);
DROP TABLE IF EXISTS `cortes`;

CREATE TABLE `cortes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hora` varchar(10) COLLATE utf8_bin NOT NULL,
  `fecha` date NOT NULL,
  `cantidad` varchar(200) COLLATE utf8_bin NOT NULL,
  `responsable` varchar(100) COLLATE utf8_bin NOT NULL,
  `vendedor` varchar(200) COLLATE utf8_bin NOT NULL,
  `porcentaje` varchar(50) COLLATE utf8_bin NOT NULL,
  `comision` varchar(100) COLLATE utf8_bin NOT NULL,
  `restante` varchar(100) COLLATE utf8_bin NOT NULL,
  `estado` varchar(50) COLLATE utf8_bin NOT NULL,
  `nota` varchar(300) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

INSERT INTO `cortes` VALUES (1,"043642","2024-04-11",285,"otreblaga@gmail.com","admin",1000,2850,-2565,"pagado","admin/corte-admin11-04-2024 04-36-44.pdf"),
(2,"043649","2024-04-11",270,"otreblaga@gmail.com","otreblaga@gmail.com",10,27,243,"pagado","otreblaga@gmail.com/corte-otreblaga@gmail.com11-04-2024 04-36-50.pdf");
DROP TABLE IF EXISTS `estilo`;

CREATE TABLE `estilo` (
  `id` varchar(200) COLLATE utf8_bin NOT NULL,
  `colorpanel` varchar(50) COLLATE utf8_bin NOT NULL,
  `coloraside` varchar(50) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `estilo` VALUES ("Vendedor","bg-success text-light","bg-success text-light"),
("admin","bg-navy text-light","bg-navy text-light"),
("Alberto garcia xdxd","bg-navy text-light","bg-navy text-light"),
("otreblaga@gmail.com","bg-purple  text-light","bg-purple  text-light");
CREATE DATABASE IF NOT EXISTS `db_hotspot_control`;

USE `db_hotspot_control`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `botones`;

CREATE TABLE `botones` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `server` varchar(100) COLLATE utf8_bin NOT NULL,
  `perfil` varchar(100) COLLATE utf8_bin NOT NULL,
  `tiempo` varchar(100) COLLATE utf8_bin NOT NULL,
  `precio` varchar(100) COLLATE utf8_bin NOT NULL,
  `legend` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` varchar(50) COLLATE utf8_bin NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `botones` VALUES (10,"1 hora","all","6Megas","1h",10,8,"[fe80::66d1:54ff:fe50:6c66%6]",1),
(11,"1 horas","all","6Megas","1h",10,9,"192.168.0.104",1),
(12,"5 horas","all","5Megas-xd","5h",23,8,"192.168.0.104",1);
DROP TABLE IF EXISTS `cards`;

CREATE TABLE `cards` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `server` varchar(50) COLLATE utf8_bin NOT NULL,
  `profile` varchar(50) COLLATE utf8_bin NOT NULL,
  `limituptime` varchar(20) COLLATE utf8_bin NOT NULL,
  `comment` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` text COLLATE utf8_bin NOT NULL,
  `descripcion` text COLLATE utf8_bin NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `cards` VALUES (1,"all","TIEMPO-CORRIDO","15d",50,"192.168.0.106","15-dias-xd",1),
(2,"all","TCORRIDO-4M","1d",20,"192.168.5.0","1-dia-cyber",1),
(3,"all","TCORRIDO-4M","15d",50,"192.168.5.0","15-dias-cyber",1),
(4,"all","default","1h",10,"192.168.5.1","1-horasddd",1),
(5,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfgf",1),
(6,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfgff",1),
(7,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfdg",1),
(8,"all","default","554645m","sdfdsfdsf","192.168.5.1","dfgdfg",1),
(9,"all","40M","30m",5,"[fe80::66d1:54ff:fe50:6c66%6]","30m",1),
(10,"all","6Megas","5h",10,"192.168.0.104","5 horas",1),
(11,"all","40M","30d",100,"192.168.0.104","un-mes-xd",1),
(12,"all","FORMAC","30m",5,"[fe80::66d1:54ff:fe50:6c66%6]","30-minutos-prueba",1);
DROP TABLE IF EXISTS `cortes`;

CREATE TABLE `cortes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hora` varchar(10) COLLATE utf8_bin NOT NULL,
  `fecha` date NOT NULL,
  `cantidad` varchar(200) COLLATE utf8_bin NOT NULL,
  `responsable` varchar(100) COLLATE utf8_bin NOT NULL,
  `vendedor` varchar(200) COLLATE utf8_bin NOT NULL,
  `porcentaje` varchar(50) COLLATE utf8_bin NOT NULL,
  `comision` varchar(100) COLLATE utf8_bin NOT NULL,
  `restante` varchar(100) COLLATE utf8_bin NOT NULL,
  `estado` varchar(50) COLLATE utf8_bin NOT NULL,
  `nota` varchar(300) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

INSERT INTO `cortes` VALUES (1,"043642","2024-04-11",285,"otreblaga@gmail.com","admin",1000,2850,-2565,"pagado","admin/corte-admin11-04-2024 04-36-44.pdf"),
(2,"043649","2024-04-11",270,"otreblaga@gmail.com","otreblaga@gmail.com",10,27,243,"pagado","otreblaga@gmail.com/corte-otreblaga@gmail.com11-04-2024 04-36-50.pdf");
DROP TABLE IF EXISTS `estilo`;

CREATE TABLE `estilo` (
  `id` varchar(200) COLLATE utf8_bin NOT NULL,
  `colorpanel` varchar(50) COLLATE utf8_bin NOT NULL,
  `coloraside` varchar(50) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `estilo` VALUES ("Vendedor","bg-success text-light","bg-success text-light"),
("admin","bg-navy text-light","bg-navy text-light"),
("Alberto garcia xdxd","bg-navy text-light","bg-navy text-light"),
("otreblaga@gmail.com","bg-purple  text-light","bg-purple  text-light");
DROP TABLE IF EXISTS `fichas`;

CREATE TABLE `fichas` (
  `id` int(50) unsigned NOT NULL AUTO_INCREMENT,
  `fecha` text COLLATE utf8_bin NOT NULL,
  `perfil` varchar(100) COLLATE utf8_bin NOT NULL,
  `tiempo` varchar(100) COLLATE utf8_bin NOT NULL,
  `user` text COLLATE utf8_bin NOT NULL,
  `pass` text COLLATE utf8_bin NOT NULL,
  `precio` varchar(100) COLLATE utf8_bin NOT NULL,
  `vendedor` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=304 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

DROP TABLE IF EXISTS `mailer`;

CREATE TABLE `mailer` (
  `id` int(10) NOT NULL,
  `nombreusuario` varchar(200) COLLATE utf8_bin NOT NULL,
  `email` varchar(200) COLLATE utf8_bin NOT NULL,
  `password` varchar(200) COLLATE utf8_bin NOT NULL,
  `host` varchar(200) COLLATE utf8_bin NOT NULL,
  `cifrado` varchar(200) COLLATE utf8_bin NOT NULL,
  `puerto` varchar(200) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `mailer` VALUES (1,"intermedioscyber@gmail.com","intermedioscyber@gmail.com","gvso ohvi omev mebf","smtp.gmail.com","PHPMailer::ENCRYPTION_STARTLS",587);
CREATE DATABASE IF NOT EXISTS `db_hotspot_control`;

USE `db_hotspot_control`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `botones`;

CREATE TABLE `botones` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `server` varchar(100) COLLATE utf8_bin NOT NULL,
  `perfil` varchar(100) COLLATE utf8_bin NOT NULL,
  `tiempo` varchar(100) COLLATE utf8_bin NOT NULL,
  `precio` varchar(100) COLLATE utf8_bin NOT NULL,
  `legend` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` varchar(50) COLLATE utf8_bin NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `botones` VALUES (10,"1 hora","all","6Megas","1h",10,8,"[fe80::66d1:54ff:fe50:6c66%6]",1),
(11,"1 horas","all","6Megas","1h",10,9,"192.168.0.104",1),
(12,"5 horas","all","5Megas-xd","5h",23,8,"192.168.0.104",1);
DROP TABLE IF EXISTS `cards`;

CREATE TABLE `cards` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `server` varchar(50) COLLATE utf8_bin NOT NULL,
  `profile` varchar(50) COLLATE utf8_bin NOT NULL,
  `limituptime` varchar(20) COLLATE utf8_bin NOT NULL,
  `comment` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` text COLLATE utf8_bin NOT NULL,
  `descripcion` text COLLATE utf8_bin NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `cards` VALUES (1,"all","TIEMPO-CORRIDO","15d",50,"192.168.0.106","15-dias-xd",1),
(2,"all","TCORRIDO-4M","1d",20,"192.168.5.0","1-dia-cyber",1),
(3,"all","TCORRIDO-4M","15d",50,"192.168.5.0","15-dias-cyber",1),
(4,"all","default","1h",10,"192.168.5.1","1-horasddd",1),
(5,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfgf",1),
(6,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfgff",1),
(7,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfdg",1),
(8,"all","default","554645m","sdfdsfdsf","192.168.5.1","dfgdfg",1),
(9,"all","40M","30m",5,"[fe80::66d1:54ff:fe50:6c66%6]","30m",1),
(10,"all","6Megas","5h",10,"192.168.0.104","5 horas",1),
(11,"all","40M","30d",100,"192.168.0.104","un-mes-xd",1),
(12,"all","FORMAC","30m",5,"[fe80::66d1:54ff:fe50:6c66%6]","30-minutos-prueba",1);
DROP TABLE IF EXISTS `cortes`;

CREATE TABLE `cortes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hora` varchar(10) COLLATE utf8_bin NOT NULL,
  `fecha` date NOT NULL,
  `cantidad` varchar(200) COLLATE utf8_bin NOT NULL,
  `responsable` varchar(100) COLLATE utf8_bin NOT NULL,
  `vendedor` varchar(200) COLLATE utf8_bin NOT NULL,
  `porcentaje` varchar(50) COLLATE utf8_bin NOT NULL,
  `comision` varchar(100) COLLATE utf8_bin NOT NULL,
  `restante` varchar(100) COLLATE utf8_bin NOT NULL,
  `estado` varchar(50) COLLATE utf8_bin NOT NULL,
  `nota` varchar(300) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

INSERT INTO `cortes` VALUES (1,"043642","2024-04-11",285,"otreblaga@gmail.com","admin",1000,2850,-2565,"pagado","admin/corte-admin11-04-2024 04-36-44.pdf"),
(2,"043649","2024-04-11",270,"otreblaga@gmail.com","otreblaga@gmail.com",10,27,243,"pagado","otreblaga@gmail.com/corte-otreblaga@gmail.com11-04-2024 04-36-50.pdf");
DROP TABLE IF EXISTS `estilo`;

CREATE TABLE `estilo` (
  `id` varchar(200) COLLATE utf8_bin NOT NULL,
  `colorpanel` varchar(50) COLLATE utf8_bin NOT NULL,
  `coloraside` varchar(50) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `estilo` VALUES ("Vendedor","bg-success text-light","bg-success text-light"),
("admin","bg-navy text-light","bg-navy text-light"),
("Alberto garcia xdxd","bg-navy text-light","bg-navy text-light"),
("otreblaga@gmail.com","bg-purple  text-light","bg-purple  text-light");
DROP TABLE IF EXISTS `fichas`;

CREATE TABLE `fichas` (
  `id` int(50) unsigned NOT NULL AUTO_INCREMENT,
  `fecha` text COLLATE utf8_bin NOT NULL,
  `perfil` varchar(100) COLLATE utf8_bin NOT NULL,
  `tiempo` varchar(100) COLLATE utf8_bin NOT NULL,
  `user` text COLLATE utf8_bin NOT NULL,
  `pass` text COLLATE utf8_bin NOT NULL,
  `precio` varchar(100) COLLATE utf8_bin NOT NULL,
  `vendedor` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=304 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

DROP TABLE IF EXISTS `mailer`;

CREATE TABLE `mailer` (
  `id` int(10) NOT NULL,
  `nombreusuario` varchar(200) COLLATE utf8_bin NOT NULL,
  `email` varchar(200) COLLATE utf8_bin NOT NULL,
  `password` varchar(200) COLLATE utf8_bin NOT NULL,
  `host` varchar(200) COLLATE utf8_bin NOT NULL,
  `cifrado` varchar(200) COLLATE utf8_bin NOT NULL,
  `puerto` varchar(200) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `mailer` VALUES (1,"intermedioscyber@gmail.com","intermedioscyber@gmail.com","gvso ohvi omev mebf","smtp.gmail.com","PHPMailer::ENCRYPTION_STARTLS",587);
DROP TABLE IF EXISTS `recoverydb`;

CREATE TABLE `recoverydb` (
  `id` int(50) NOT NULL,
  `code` varchar(100) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `recoverydb` VALUES (1708874878,"RzCVRc5l74",""),
(1708891951,"zYun7MwxP1",""),
(1708891470,"Jv6RS6fOs9","");
CREATE DATABASE IF NOT EXISTS `db_hotspot_control`;

USE `db_hotspot_control`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `botones`;

CREATE TABLE `botones` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `server` varchar(100) COLLATE utf8_bin NOT NULL,
  `perfil` varchar(100) COLLATE utf8_bin NOT NULL,
  `tiempo` varchar(100) COLLATE utf8_bin NOT NULL,
  `precio` varchar(100) COLLATE utf8_bin NOT NULL,
  `legend` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` varchar(50) COLLATE utf8_bin NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `botones` VALUES (10,"1 hora","all","6Megas","1h",10,8,"[fe80::66d1:54ff:fe50:6c66%6]",1),
(11,"1 horas","all","6Megas","1h",10,9,"192.168.0.104",1),
(12,"5 horas","all","5Megas-xd","5h",23,8,"192.168.0.104",1);
DROP TABLE IF EXISTS `cards`;

CREATE TABLE `cards` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `server` varchar(50) COLLATE utf8_bin NOT NULL,
  `profile` varchar(50) COLLATE utf8_bin NOT NULL,
  `limituptime` varchar(20) COLLATE utf8_bin NOT NULL,
  `comment` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` text COLLATE utf8_bin NOT NULL,
  `descripcion` text COLLATE utf8_bin NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `cards` VALUES (1,"all","TIEMPO-CORRIDO","15d",50,"192.168.0.106","15-dias-xd",1),
(2,"all","TCORRIDO-4M","1d",20,"192.168.5.0","1-dia-cyber",1),
(3,"all","TCORRIDO-4M","15d",50,"192.168.5.0","15-dias-cyber",1),
(4,"all","default","1h",10,"192.168.5.1","1-horasddd",1),
(5,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfgf",1),
(6,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfgff",1),
(7,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfdg",1),
(8,"all","default","554645m","sdfdsfdsf","192.168.5.1","dfgdfg",1),
(9,"all","40M","30m",5,"[fe80::66d1:54ff:fe50:6c66%6]","30m",1),
(10,"all","6Megas","5h",10,"192.168.0.104","5 horas",1),
(11,"all","40M","30d",100,"192.168.0.104","un-mes-xd",1),
(12,"all","FORMAC","30m",5,"[fe80::66d1:54ff:fe50:6c66%6]","30-minutos-prueba",1);
DROP TABLE IF EXISTS `cortes`;

CREATE TABLE `cortes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hora` varchar(10) COLLATE utf8_bin NOT NULL,
  `fecha` date NOT NULL,
  `cantidad` varchar(200) COLLATE utf8_bin NOT NULL,
  `responsable` varchar(100) COLLATE utf8_bin NOT NULL,
  `vendedor` varchar(200) COLLATE utf8_bin NOT NULL,
  `porcentaje` varchar(50) COLLATE utf8_bin NOT NULL,
  `comision` varchar(100) COLLATE utf8_bin NOT NULL,
  `restante` varchar(100) COLLATE utf8_bin NOT NULL,
  `estado` varchar(50) COLLATE utf8_bin NOT NULL,
  `nota` varchar(300) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

INSERT INTO `cortes` VALUES (1,"043642","2024-04-11",285,"otreblaga@gmail.com","admin",1000,2850,-2565,"pagado","admin/corte-admin11-04-2024 04-36-44.pdf"),
(2,"043649","2024-04-11",270,"otreblaga@gmail.com","otreblaga@gmail.com",10,27,243,"pagado","otreblaga@gmail.com/corte-otreblaga@gmail.com11-04-2024 04-36-50.pdf");
DROP TABLE IF EXISTS `estilo`;

CREATE TABLE `estilo` (
  `id` varchar(200) COLLATE utf8_bin NOT NULL,
  `colorpanel` varchar(50) COLLATE utf8_bin NOT NULL,
  `coloraside` varchar(50) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `estilo` VALUES ("Vendedor","bg-success text-light","bg-success text-light"),
("admin","bg-navy text-light","bg-navy text-light"),
("Alberto garcia xdxd","bg-navy text-light","bg-navy text-light"),
("otreblaga@gmail.com","bg-purple  text-light","bg-purple  text-light");
DROP TABLE IF EXISTS `fichas`;

CREATE TABLE `fichas` (
  `id` int(50) unsigned NOT NULL AUTO_INCREMENT,
  `fecha` text COLLATE utf8_bin NOT NULL,
  `perfil` varchar(100) COLLATE utf8_bin NOT NULL,
  `tiempo` varchar(100) COLLATE utf8_bin NOT NULL,
  `user` text COLLATE utf8_bin NOT NULL,
  `pass` text COLLATE utf8_bin NOT NULL,
  `precio` varchar(100) COLLATE utf8_bin NOT NULL,
  `vendedor` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=304 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

DROP TABLE IF EXISTS `mailer`;

CREATE TABLE `mailer` (
  `id` int(10) NOT NULL,
  `nombreusuario` varchar(200) COLLATE utf8_bin NOT NULL,
  `email` varchar(200) COLLATE utf8_bin NOT NULL,
  `password` varchar(200) COLLATE utf8_bin NOT NULL,
  `host` varchar(200) COLLATE utf8_bin NOT NULL,
  `cifrado` varchar(200) COLLATE utf8_bin NOT NULL,
  `puerto` varchar(200) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `mailer` VALUES (1,"intermedioscyber@gmail.com","intermedioscyber@gmail.com","gvso ohvi omev mebf","smtp.gmail.com","PHPMailer::ENCRYPTION_STARTLS",587);
DROP TABLE IF EXISTS `recoverydb`;

CREATE TABLE `recoverydb` (
  `id` int(50) NOT NULL,
  `code` varchar(100) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `recoverydb` VALUES (1708874878,"RzCVRc5l74",""),
(1708891951,"zYun7MwxP1",""),
(1708891470,"Jv6RS6fOs9","");
DROP TABLE IF EXISTS `routerboard`;

CREATE TABLE `routerboard` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `usuario` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `puerto` int(5) NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `routerboard` VALUES (9,"192.168.0.104","admin","admin","admin",8728,1),
(10,"[fe80::66d1:54ff:fe50:6c66%6]","Alberto garcia xdxd","admin","admin",8728,1),
(11,"[fe80::66d1:54ff:fe50:6c66%6]","Vendedor demo 1","Vendedor","Vendedor",8728,1),
(12,"192.168.5.1","otreblaga@gmail.com","otreblaga@gmail.com","January2019",8728,1),
(13,"192.168.5.0","otreblaga@gmail.com","otreblaga@gmail.com","January2019",8756,1),
(14,"192.168.30.1","admin","admin","admin",8728,1),
(15,"192.168.0.105","admin","admin","admin",8728,1);
CREATE DATABASE IF NOT EXISTS `db_hotspot_control`;

USE `db_hotspot_control`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `botones`;

CREATE TABLE `botones` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `server` varchar(100) COLLATE utf8_bin NOT NULL,
  `perfil` varchar(100) COLLATE utf8_bin NOT NULL,
  `tiempo` varchar(100) COLLATE utf8_bin NOT NULL,
  `precio` varchar(100) COLLATE utf8_bin NOT NULL,
  `legend` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` varchar(50) COLLATE utf8_bin NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `botones` VALUES (10,"1 hora","all","6Megas","1h",10,8,"[fe80::66d1:54ff:fe50:6c66%6]",1),
(11,"1 horas","all","6Megas","1h",10,9,"192.168.0.104",1),
(12,"5 horas","all","5Megas-xd","5h",23,8,"192.168.0.104",1);
DROP TABLE IF EXISTS `cards`;

CREATE TABLE `cards` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `server` varchar(50) COLLATE utf8_bin NOT NULL,
  `profile` varchar(50) COLLATE utf8_bin NOT NULL,
  `limituptime` varchar(20) COLLATE utf8_bin NOT NULL,
  `comment` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` text COLLATE utf8_bin NOT NULL,
  `descripcion` text COLLATE utf8_bin NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `cards` VALUES (1,"all","TIEMPO-CORRIDO","15d",50,"192.168.0.106","15-dias-xd",1),
(2,"all","TCORRIDO-4M","1d",20,"192.168.5.0","1-dia-cyber",1),
(3,"all","TCORRIDO-4M","15d",50,"192.168.5.0","15-dias-cyber",1),
(4,"all","default","1h",10,"192.168.5.1","1-horasddd",1),
(5,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfgf",1),
(6,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfgff",1),
(7,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfdg",1),
(8,"all","default","554645m","sdfdsfdsf","192.168.5.1","dfgdfg",1),
(9,"all","40M","30m",5,"[fe80::66d1:54ff:fe50:6c66%6]","30m",1),
(10,"all","6Megas","5h",10,"192.168.0.104","5 horas",1),
(11,"all","40M","30d",100,"192.168.0.104","un-mes-xd",1),
(12,"all","FORMAC","30m",5,"[fe80::66d1:54ff:fe50:6c66%6]","30-minutos-prueba",1);
DROP TABLE IF EXISTS `cortes`;

CREATE TABLE `cortes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hora` varchar(10) COLLATE utf8_bin NOT NULL,
  `fecha` date NOT NULL,
  `cantidad` varchar(200) COLLATE utf8_bin NOT NULL,
  `responsable` varchar(100) COLLATE utf8_bin NOT NULL,
  `vendedor` varchar(200) COLLATE utf8_bin NOT NULL,
  `porcentaje` varchar(50) COLLATE utf8_bin NOT NULL,
  `comision` varchar(100) COLLATE utf8_bin NOT NULL,
  `restante` varchar(100) COLLATE utf8_bin NOT NULL,
  `estado` varchar(50) COLLATE utf8_bin NOT NULL,
  `nota` varchar(300) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

INSERT INTO `cortes` VALUES (1,"043642","2024-04-11",285,"otreblaga@gmail.com","admin",1000,2850,-2565,"pagado","admin/corte-admin11-04-2024 04-36-44.pdf"),
(2,"043649","2024-04-11",270,"otreblaga@gmail.com","otreblaga@gmail.com",10,27,243,"pagado","otreblaga@gmail.com/corte-otreblaga@gmail.com11-04-2024 04-36-50.pdf");
DROP TABLE IF EXISTS `estilo`;

CREATE TABLE `estilo` (
  `id` varchar(200) COLLATE utf8_bin NOT NULL,
  `colorpanel` varchar(50) COLLATE utf8_bin NOT NULL,
  `coloraside` varchar(50) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `estilo` VALUES ("Vendedor","bg-success text-light","bg-success text-light"),
("admin","bg-navy text-light","bg-navy text-light"),
("Alberto garcia xdxd","bg-navy text-light","bg-navy text-light"),
("otreblaga@gmail.com","bg-purple  text-light","bg-purple  text-light");
DROP TABLE IF EXISTS `fichas`;

CREATE TABLE `fichas` (
  `id` int(50) unsigned NOT NULL AUTO_INCREMENT,
  `fecha` text COLLATE utf8_bin NOT NULL,
  `perfil` varchar(100) COLLATE utf8_bin NOT NULL,
  `tiempo` varchar(100) COLLATE utf8_bin NOT NULL,
  `user` text COLLATE utf8_bin NOT NULL,
  `pass` text COLLATE utf8_bin NOT NULL,
  `precio` varchar(100) COLLATE utf8_bin NOT NULL,
  `vendedor` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=304 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

DROP TABLE IF EXISTS `mailer`;

CREATE TABLE `mailer` (
  `id` int(10) NOT NULL,
  `nombreusuario` varchar(200) COLLATE utf8_bin NOT NULL,
  `email` varchar(200) COLLATE utf8_bin NOT NULL,
  `password` varchar(200) COLLATE utf8_bin NOT NULL,
  `host` varchar(200) COLLATE utf8_bin NOT NULL,
  `cifrado` varchar(200) COLLATE utf8_bin NOT NULL,
  `puerto` varchar(200) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `mailer` VALUES (1,"intermedioscyber@gmail.com","intermedioscyber@gmail.com","gvso ohvi omev mebf","smtp.gmail.com","PHPMailer::ENCRYPTION_STARTLS",587);
DROP TABLE IF EXISTS `recoverydb`;

CREATE TABLE `recoverydb` (
  `id` int(50) NOT NULL,
  `code` varchar(100) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `recoverydb` VALUES (1708874878,"RzCVRc5l74",""),
(1708891951,"zYun7MwxP1",""),
(1708891470,"Jv6RS6fOs9","");
DROP TABLE IF EXISTS `routerboard`;

CREATE TABLE `routerboard` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `usuario` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `puerto` int(5) NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `routerboard` VALUES (9,"192.168.0.104","admin","admin","admin",8728,1),
(10,"[fe80::66d1:54ff:fe50:6c66%6]","Alberto garcia xdxd","admin","admin",8728,1),
(11,"[fe80::66d1:54ff:fe50:6c66%6]","Vendedor demo 1","Vendedor","Vendedor",8728,1),
(12,"192.168.5.1","otreblaga@gmail.com","otreblaga@gmail.com","January2019",8728,1),
(13,"192.168.5.0","otreblaga@gmail.com","otreblaga@gmail.com","January2019",8756,1),
(14,"192.168.30.1","admin","admin","admin",8728,1),
(15,"192.168.0.105","admin","admin","admin",8728,1);
DROP TABLE IF EXISTS `sistema`;

CREATE TABLE `sistema` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sistema` varchar(100) COLLATE utf8_bin NOT NULL,
  `logo` varchar(100) COLLATE utf8_bin NOT NULL,
  `idusuario` varchar(100) COLLATE utf8_bin NOT NULL,
  `idpassword` varchar(100) COLLATE utf8_bin NOT NULL,
  `texto` varchar(100) COLLATE utf8_bin NOT NULL,
  `zona` text COLLATE utf8_bin NOT NULL,
  `moneda` text COLLATE utf8_bin NOT NULL,
  `modo` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `sistema` VALUES (1,"Intermedio","logo/logo98.png","Usuario","Contraseña","Welcome","America/Mexico_City","$",10);
CREATE DATABASE IF NOT EXISTS `db_hotspot_control`;

USE `db_hotspot_control`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `botones`;

CREATE TABLE `botones` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `server` varchar(100) COLLATE utf8_bin NOT NULL,
  `perfil` varchar(100) COLLATE utf8_bin NOT NULL,
  `tiempo` varchar(100) COLLATE utf8_bin NOT NULL,
  `precio` varchar(100) COLLATE utf8_bin NOT NULL,
  `legend` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` varchar(50) COLLATE utf8_bin NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `botones` VALUES (10,"1 hora","all","6Megas","1h",10,8,"[fe80::66d1:54ff:fe50:6c66%6]",1),
(11,"1 horas","all","6Megas","1h",10,9,"192.168.0.104",1),
(12,"5 horas","all","5Megas-xd","5h",23,8,"192.168.0.104",1);
DROP TABLE IF EXISTS `cards`;

CREATE TABLE `cards` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `server` varchar(50) COLLATE utf8_bin NOT NULL,
  `profile` varchar(50) COLLATE utf8_bin NOT NULL,
  `limituptime` varchar(20) COLLATE utf8_bin NOT NULL,
  `comment` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` text COLLATE utf8_bin NOT NULL,
  `descripcion` text COLLATE utf8_bin NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `cards` VALUES (1,"all","TIEMPO-CORRIDO","15d",50,"192.168.0.106","15-dias-xd",1),
(2,"all","TCORRIDO-4M","1d",20,"192.168.5.0","1-dia-cyber",1),
(3,"all","TCORRIDO-4M","15d",50,"192.168.5.0","15-dias-cyber",1),
(4,"all","default","1h",10,"192.168.5.1","1-horasddd",1),
(5,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfgf",1),
(6,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfgff",1),
(7,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfdg",1),
(8,"all","default","554645m","sdfdsfdsf","192.168.5.1","dfgdfg",1),
(9,"all","40M","30m",5,"[fe80::66d1:54ff:fe50:6c66%6]","30m",1),
(10,"all","6Megas","5h",10,"192.168.0.104","5 horas",1),
(11,"all","40M","30d",100,"192.168.0.104","un-mes-xd",1),
(12,"all","FORMAC","30m",5,"[fe80::66d1:54ff:fe50:6c66%6]","30-minutos-prueba",1);
DROP TABLE IF EXISTS `cortes`;

CREATE TABLE `cortes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hora` varchar(10) COLLATE utf8_bin NOT NULL,
  `fecha` date NOT NULL,
  `cantidad` varchar(200) COLLATE utf8_bin NOT NULL,
  `responsable` varchar(100) COLLATE utf8_bin NOT NULL,
  `vendedor` varchar(200) COLLATE utf8_bin NOT NULL,
  `porcentaje` varchar(50) COLLATE utf8_bin NOT NULL,
  `comision` varchar(100) COLLATE utf8_bin NOT NULL,
  `restante` varchar(100) COLLATE utf8_bin NOT NULL,
  `estado` varchar(50) COLLATE utf8_bin NOT NULL,
  `nota` varchar(300) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

INSERT INTO `cortes` VALUES (1,"043642","2024-04-11",285,"otreblaga@gmail.com","admin",1000,2850,-2565,"pagado","admin/corte-admin11-04-2024 04-36-44.pdf"),
(2,"043649","2024-04-11",270,"otreblaga@gmail.com","otreblaga@gmail.com",10,27,243,"pagado","otreblaga@gmail.com/corte-otreblaga@gmail.com11-04-2024 04-36-50.pdf");
DROP TABLE IF EXISTS `estilo`;

CREATE TABLE `estilo` (
  `id` varchar(200) COLLATE utf8_bin NOT NULL,
  `colorpanel` varchar(50) COLLATE utf8_bin NOT NULL,
  `coloraside` varchar(50) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `estilo` VALUES ("Vendedor","bg-success text-light","bg-success text-light"),
("admin","bg-navy text-light","bg-navy text-light"),
("Alberto garcia xdxd","bg-navy text-light","bg-navy text-light"),
("otreblaga@gmail.com","bg-purple  text-light","bg-purple  text-light");
DROP TABLE IF EXISTS `fichas`;

CREATE TABLE `fichas` (
  `id` int(50) unsigned NOT NULL AUTO_INCREMENT,
  `fecha` text COLLATE utf8_bin NOT NULL,
  `perfil` varchar(100) COLLATE utf8_bin NOT NULL,
  `tiempo` varchar(100) COLLATE utf8_bin NOT NULL,
  `user` text COLLATE utf8_bin NOT NULL,
  `pass` text COLLATE utf8_bin NOT NULL,
  `precio` varchar(100) COLLATE utf8_bin NOT NULL,
  `vendedor` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=304 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

DROP TABLE IF EXISTS `mailer`;

CREATE TABLE `mailer` (
  `id` int(10) NOT NULL,
  `nombreusuario` varchar(200) COLLATE utf8_bin NOT NULL,
  `email` varchar(200) COLLATE utf8_bin NOT NULL,
  `password` varchar(200) COLLATE utf8_bin NOT NULL,
  `host` varchar(200) COLLATE utf8_bin NOT NULL,
  `cifrado` varchar(200) COLLATE utf8_bin NOT NULL,
  `puerto` varchar(200) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `mailer` VALUES (1,"intermedioscyber@gmail.com","intermedioscyber@gmail.com","gvso ohvi omev mebf","smtp.gmail.com","PHPMailer::ENCRYPTION_STARTLS",587);
DROP TABLE IF EXISTS `recoverydb`;

CREATE TABLE `recoverydb` (
  `id` int(50) NOT NULL,
  `code` varchar(100) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `recoverydb` VALUES (1708874878,"RzCVRc5l74",""),
(1708891951,"zYun7MwxP1",""),
(1708891470,"Jv6RS6fOs9","");
DROP TABLE IF EXISTS `routerboard`;

CREATE TABLE `routerboard` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `usuario` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `puerto` int(5) NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `routerboard` VALUES (9,"192.168.0.104","admin","admin","admin",8728,1),
(10,"[fe80::66d1:54ff:fe50:6c66%6]","Alberto garcia xdxd","admin","admin",8728,1),
(11,"[fe80::66d1:54ff:fe50:6c66%6]","Vendedor demo 1","Vendedor","Vendedor",8728,1),
(12,"192.168.5.1","otreblaga@gmail.com","otreblaga@gmail.com","January2019",8728,1),
(13,"192.168.5.0","otreblaga@gmail.com","otreblaga@gmail.com","January2019",8756,1),
(14,"192.168.30.1","admin","admin","admin",8728,1),
(15,"192.168.0.105","admin","admin","admin",8728,1);
DROP TABLE IF EXISTS `sistema`;

CREATE TABLE `sistema` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sistema` varchar(100) COLLATE utf8_bin NOT NULL,
  `logo` varchar(100) COLLATE utf8_bin NOT NULL,
  `idusuario` varchar(100) COLLATE utf8_bin NOT NULL,
  `idpassword` varchar(100) COLLATE utf8_bin NOT NULL,
  `texto` varchar(100) COLLATE utf8_bin NOT NULL,
  `zona` text COLLATE utf8_bin NOT NULL,
  `moneda` text COLLATE utf8_bin NOT NULL,
  `modo` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `sistema` VALUES (1,"Intermedio","logo/logo98.png","Usuario","Contraseña","Welcome","America/Mexico_City","$",10);
DROP TABLE IF EXISTS `sucursal`;

CREATE TABLE `sucursal` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `direccion` varchar(300) COLLATE utf8_bin NOT NULL,
  `texto` varchar(300) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `sucursal` VALUES (1,"Intermedios","Camino a Dolores","Conéctate a  Intermedios");
CREATE DATABASE IF NOT EXISTS `db_hotspot_control`;

USE `db_hotspot_control`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `botones`;

CREATE TABLE `botones` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `server` varchar(100) COLLATE utf8_bin NOT NULL,
  `perfil` varchar(100) COLLATE utf8_bin NOT NULL,
  `tiempo` varchar(100) COLLATE utf8_bin NOT NULL,
  `precio` varchar(100) COLLATE utf8_bin NOT NULL,
  `legend` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` varchar(50) COLLATE utf8_bin NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `botones` VALUES (10,"1 hora","all","6Megas","1h",10,8,"[fe80::66d1:54ff:fe50:6c66%6]",1),
(11,"1 horas","all","6Megas","1h",10,9,"192.168.0.104",1),
(12,"5 horas","all","5Megas-xd","5h",23,8,"192.168.0.104",1);
DROP TABLE IF EXISTS `cards`;

CREATE TABLE `cards` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `server` varchar(50) COLLATE utf8_bin NOT NULL,
  `profile` varchar(50) COLLATE utf8_bin NOT NULL,
  `limituptime` varchar(20) COLLATE utf8_bin NOT NULL,
  `comment` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` text COLLATE utf8_bin NOT NULL,
  `descripcion` text COLLATE utf8_bin NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `cards` VALUES (1,"all","TIEMPO-CORRIDO","15d",50,"192.168.0.106","15-dias-xd",1),
(2,"all","TCORRIDO-4M","1d",20,"192.168.5.0","1-dia-cyber",1),
(3,"all","TCORRIDO-4M","15d",50,"192.168.5.0","15-dias-cyber",1),
(4,"all","default","1h",10,"192.168.5.1","1-horasddd",1),
(5,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfgf",1),
(6,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfgff",1),
(7,"all","default","554645m","sdfdsfdsf","192.168.5.1","gdfdg",1),
(8,"all","default","554645m","sdfdsfdsf","192.168.5.1","dfgdfg",1),
(9,"all","40M","30m",5,"[fe80::66d1:54ff:fe50:6c66%6]","30m",1),
(10,"all","6Megas","5h",10,"192.168.0.104","5 horas",1),
(11,"all","40M","30d",100,"192.168.0.104","un-mes-xd",1),
(12,"all","FORMAC","30m",5,"[fe80::66d1:54ff:fe50:6c66%6]","30-minutos-prueba",1);
DROP TABLE IF EXISTS `cortes`;

CREATE TABLE `cortes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hora` varchar(10) COLLATE utf8_bin NOT NULL,
  `fecha` date NOT NULL,
  `cantidad` varchar(200) COLLATE utf8_bin NOT NULL,
  `responsable` varchar(100) COLLATE utf8_bin NOT NULL,
  `vendedor` varchar(200) COLLATE utf8_bin NOT NULL,
  `porcentaje` varchar(50) COLLATE utf8_bin NOT NULL,
  `comision` varchar(100) COLLATE utf8_bin NOT NULL,
  `restante` varchar(100) COLLATE utf8_bin NOT NULL,
  `estado` varchar(50) COLLATE utf8_bin NOT NULL,
  `nota` varchar(300) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

INSERT INTO `cortes` VALUES (1,"043642","2024-04-11",285,"otreblaga@gmail.com","admin",1000,2850,-2565,"pagado","admin/corte-admin11-04-2024 04-36-44.pdf"),
(2,"043649","2024-04-11",270,"otreblaga@gmail.com","otreblaga@gmail.com",10,27,243,"pagado","otreblaga@gmail.com/corte-otreblaga@gmail.com11-04-2024 04-36-50.pdf");
DROP TABLE IF EXISTS `estilo`;

CREATE TABLE `estilo` (
  `id` varchar(200) COLLATE utf8_bin NOT NULL,
  `colorpanel` varchar(50) COLLATE utf8_bin NOT NULL,
  `coloraside` varchar(50) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `estilo` VALUES ("Vendedor","bg-success text-light","bg-success text-light"),
("admin","bg-navy text-light","bg-navy text-light"),
("Alberto garcia xdxd","bg-navy text-light","bg-navy text-light"),
("otreblaga@gmail.com","bg-purple  text-light","bg-purple  text-light");
DROP TABLE IF EXISTS `fichas`;

CREATE TABLE `fichas` (
  `id` int(50) unsigned NOT NULL AUTO_INCREMENT,
  `fecha` text COLLATE utf8_bin NOT NULL,
  `perfil` varchar(100) COLLATE utf8_bin NOT NULL,
  `tiempo` varchar(100) COLLATE utf8_bin NOT NULL,
  `user` text COLLATE utf8_bin NOT NULL,
  `pass` text COLLATE utf8_bin NOT NULL,
  `precio` varchar(100) COLLATE utf8_bin NOT NULL,
  `vendedor` varchar(100) COLLATE utf8_bin NOT NULL,
  `mikrotik` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=304 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

DROP TABLE IF EXISTS `mailer`;

CREATE TABLE `mailer` (
  `id` int(10) NOT NULL,
  `nombreusuario` varchar(200) COLLATE utf8_bin NOT NULL,
  `email` varchar(200) COLLATE utf8_bin NOT NULL,
  `password` varchar(200) COLLATE utf8_bin NOT NULL,
  `host` varchar(200) COLLATE utf8_bin NOT NULL,
  `cifrado` varchar(200) COLLATE utf8_bin NOT NULL,
  `puerto` varchar(200) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `mailer` VALUES (1,"intermedioscyber@gmail.com","intermedioscyber@gmail.com","gvso ohvi omev mebf","smtp.gmail.com","PHPMailer::ENCRYPTION_STARTLS",587);
DROP TABLE IF EXISTS `recoverydb`;

CREATE TABLE `recoverydb` (
  `id` int(50) NOT NULL,
  `code` varchar(100) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `recoverydb` VALUES (1708874878,"RzCVRc5l74",""),
(1708891951,"zYun7MwxP1",""),
(1708891470,"Jv6RS6fOs9","");
DROP TABLE IF EXISTS `routerboard`;

CREATE TABLE `routerboard` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `usuario` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `puerto` int(5) NOT NULL,
  `idsucursal` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `routerboard` VALUES (9,"192.168.0.104","admin","admin","admin",8728,1),
(10,"[fe80::66d1:54ff:fe50:6c66%6]","Alberto garcia xdxd","admin","admin",8728,1),
(11,"[fe80::66d1:54ff:fe50:6c66%6]","Vendedor demo 1","Vendedor","Vendedor",8728,1),
(12,"192.168.5.1","otreblaga@gmail.com","otreblaga@gmail.com","January2019",8728,1),
(13,"192.168.5.0","otreblaga@gmail.com","otreblaga@gmail.com","January2019",8756,1),
(14,"192.168.30.1","admin","admin","admin",8728,1),
(15,"192.168.0.105","admin","admin","admin",8728,1);
DROP TABLE IF EXISTS `sistema`;

CREATE TABLE `sistema` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sistema` varchar(100) COLLATE utf8_bin NOT NULL,
  `logo` varchar(100) COLLATE utf8_bin NOT NULL,
  `idusuario` varchar(100) COLLATE utf8_bin NOT NULL,
  `idpassword` varchar(100) COLLATE utf8_bin NOT NULL,
  `texto` varchar(100) COLLATE utf8_bin NOT NULL,
  `zona` text COLLATE utf8_bin NOT NULL,
  `moneda` text COLLATE utf8_bin NOT NULL,
  `modo` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `sistema` VALUES (1,"Intermedio","logo/logo98.png","Usuario","Contraseña","Welcome","America/Mexico_City","$",10);
DROP TABLE IF EXISTS `sucursal`;

CREATE TABLE `sucursal` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_bin NOT NULL,
  `direccion` varchar(300) COLLATE utf8_bin NOT NULL,
  `texto` varchar(300) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `sucursal` VALUES (1,"Intermedios","Camino a Dolores","Conéctate a  Intermedios");
SET foreign_key_checks = 1;
